from flask import Flask, request, jsonify
import requests
from flask_cors import CORS  # 导入 CORS
import json
app = Flask(__name__)
CORS(app)  # 允许所有来源跨域请求，如果需要可配置细化


REMOTE_API = "http://1.94.9.72:5000/predict"

@app.route('/proxy_predict', methods=['POST'])
def proxy_predict():
    # 接收前端传来的JSON数据
    input_data = request.get_json()
    
    try:
        # 转发请求到远程服务器
        resp = requests.post(REMOTE_API, json=input_data)
        resp.raise_for_status()
        result = resp.json()
        print("[远程预测响应]：", json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as e:
        return jsonify({"error": "调用远程API失败", "detail": str(e)}), 500
    
    # 返回远程服务器的响应结果给前端
    return jsonify(resp.json())



if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
