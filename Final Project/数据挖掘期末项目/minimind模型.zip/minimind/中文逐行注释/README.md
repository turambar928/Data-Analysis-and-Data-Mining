此目录对[minimind(截至2024-09-20版)](https://github.com/jingyaogong/minimind/tree/c28664dac8cc7eec83dcf6c03decc0ec40ded44d)
重要的代码进行了逐行注释

感谢[@chuanzhubin](https://github.com/chuanzhubin)贡献此部分内容

很大程度方便了学习者快速理解