# XGBoost 糖尿病预测 API

## 项目简介
基于公开的糖尿病预测数据集，使用 **XGBoost** 训练二分类模型，并封装为 **Flask RESTful API**，可对单条或批量样本进行糖尿病患病风险预测。

<p align="center"><img src="https://raw.githubusercontent.com/yl-ms/asset-repo/main/diabetes-cover.png" width="600"></p>

---

## 目录结构
```text
│  app.py                 # Flask API 主程序
│  xgboost_model.py       # 训练脚本（含可视化与模型保存）
│  xgboost_model.pkl      # 训练好的模型（二进制格式）
│  xgboost_model.json     # 训练好的模型（JSON 格式，跨版本兼容性更好）
│  requirements.txt       # Python 依赖清单
│  start.sh               # Linux 一键启动脚本（Gunicorn）
└─ .idea / .git           # 配置与版本控制文件
```

---

## 环境依赖
- Python 3.9+（建议使用 virtualenv / conda 创建隔离环境）
- 依赖包详见 `requirements.txt`

安装依赖：
```bash
pip install -r requirements.txt
```

如需 GPU 训练 / 推理，可自行安装带 CUDA 的 `xgboost` 版本。

---

## 快速开始
### 1. 加载已训练模型并启动 API
确保 **xgboost_model.pkl / xgboost_model.json** 位于项目根目录，执行：
```bash
python app.py
```
默认监听 `http://0.0.0.0:5000`。

也可在 Linux 环境使用多进程生产服务：
```bash
bash start.sh
```

启动成功后访问根路由查看状态：
```bash
curl http://localhost:5000/
```

### 2. 端点说明
| 方法 | 路径 | 说明 |
|------|------|------|
| GET  | `/`            | API 信息 |
| GET  | `/health`      | 心跳监测，返回模型加载状态 |
| POST | `/predict`     | 单条样本预测 |
| POST | `/predict_batch` | 批量预测，Body 需包含 `data` 数组 |

### 3. 请求示例
#### 单条预测
```bash
curl -X POST http://localhost:5000/predict \ 
     -H "Content-Type: application/json" \ 
     -d '{
           "age": 45,
           "gender": "Male",
           "bmi": 28.7,
           "HbA1c_level": 6.2,
           "blood_glucose_level": 155,
           "smoking_history": "never",
           "hypertension": 0,
           "heart_disease": 0
         }'
```

返回示例
```json
{
  "prediction": 1,
  "prediction_text": "糖尿病",
  "probability": {
    "non_diabetes": 0.23,
    "diabetes": 0.77
  },
  "confidence": 0.77,
  "input_data": { ... }
}
```

#### 批量预测
```bash
curl -X POST http://localhost:5000/predict_batch \ 
     -H "Content-Type: application/json" \ 
     -d '{
           "data": [ {<样本1>}, {<样本2>} ]
         }'
```

---

## 重新训练模型
1. 准备 [diabetes_prediction_dataset.csv](https://www.kaggle.com/datasets/iammustafatz/diabetes-prediction-dataset) 到项目根目录。
2. 运行 `python xgboost_model.py`，脚本将：
   - 进行探索性数据分析与可视化
   - 预处理、标准化与 SMOTE 过采样
   - 使用随机搜索 (`RandomizedSearchCV`) 调参
   - 评估并保存最佳模型为 **.pkl / .json**

训练完成后，重新启动 API 即可生效。

---

## 参考
- XGBoost: https://xgboost.readthedocs.io/
- Flask: https://flask.palletsprojects.com/
- Imbalanced-learn: https://imbalanced-learn.org/

> 本项目仅供教学与交流使用，切勿直接用于医疗诊断。 