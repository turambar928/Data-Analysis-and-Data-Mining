Team 10
mindspore 模型提交内容
包括：
1. model：包含模型代码、参数以及权重（model code and weight文件夹）
		包含requirements.txt
2. test_data_01_results.txt：数据集1的预测结果
3. test_data_02_results.txt：数据集2的预测结果