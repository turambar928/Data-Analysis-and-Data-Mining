Team 10
xgboost模型提交内容

目录结构

-  
  ├── **model/**  
  │   ├── **model code and weight/**    # 包含模型代码和权重文件  
  │   └── **requirements.txt**         # 包含项目所需的依赖库  
  ├── **test_data_01_result.txt**      # 使用数据集 01 进行预测的结果  
  ├── **test_data_02_result.txt**      # 使用数据集 02 进行预测的结果  
  └── **readme.txt**                   # 本文件，提供项目说明和使用方法

